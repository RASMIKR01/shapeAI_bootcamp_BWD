import React from "react";

function Info() {
  return (
    <div class="note">
      <h1 class="note">Javascript and React.js</h1>
      <p class="note">A basic web dev React JS Bootcamp</p>
    </div>
  );
}

export default Info;
